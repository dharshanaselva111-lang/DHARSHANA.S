# Portfolio the future of smart machines

A Pen created on CodePen.

Original URL: [https://codepen.io/khglsfzs-the-animator/pen/dPYwwzG](https://codepen.io/khglsfzs-the-animator/pen/dPYwwzG).

